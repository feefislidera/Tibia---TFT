
import React from 'react';
import { levelUpStats } from '../../game/logic';

export function UnitCard({ u }: { u: any }) {
  const base = u.base || u;
  const level = u.level || 1;
  const stats = u.level ? levelUpStats(u) : { atk: base.atk, def: base.def, sup: base.sup };
  return (
    <div className="p-3 rounded-2xl border border-slate-800 bg-slate-900">
      <div className="flex items-center justify-between">
        <div className="font-semibold text-sm">{base.name}{level===2?' ★':''}</div>
        <div className="pill">C{base.cost}</div>
      </div>
      <div className="mt-1 text-xs opacity-70">{base.tribe}</div>
      <div className="mt-2 grid grid-cols-3 gap-2 text-xs">
        <div>ATK {stats.atk}</div>
        <div>DEF {stats.def}</div>
        <div>SUP {stats.sup}</div>
      </div>
      <div className="mt-1 text-[11px] opacity-60">Vida-Perdida: {base.vidaPerdida}</div>
    </div>
  );
}
