
import React, { useEffect, useState } from 'react';
import { onValue } from 'firebase/database';
import { getOrCreateClient } from '../lib/client';
import { getRoomRef, setReady, startGame, buyCard, reroll, deployFromBench, removeFromBoard, leaveRoom, autoDeploy, isOwner, nextPhaseIfNeeded } from '../lib/room';
import { allowedCostsForRound } from '../game/logic';
import { UnitCard } from './unit/UnitCard';

export function Room({ code, goHome }: { code: string, goHome: ()=>void }) {
  const me = getOrCreateClient();
  const [room, setRoom] = useState<any>(null);

  useEffect(()=>{
    const r = getRoomRef(code);
    return onValue(r, snap => {
      setRoom(snap.val());
    });
  }, [code]);

  useEffect(()=>{
    if (room) nextPhaseIfNeeded(code, room);
  }, [room]);

  if (!room) return <div className="p-6">Carregando sala...</div>;

  const meIdx = (room.players||[]).findIndex((p:any)=>p.uid===me.uid);
  const mePlayer = room.players?.[meIdx];
  const myShop = room.shop?.[me.uid] || [];
  const canStart = isOwner(room, me.uid) && room.status==='lobby' && (room.players||[]).length===4 && room.players.every((p:any)=>p.ready);

  return (
    <div className="max-w-6xl mx-auto p-4 grid gap-4">
      <header className="flex items-center justify-between">
        <div className="grid">
          <div className="text-sm opacity-60">Sala</div>
          <h2 className="text-xl font-bold tracking-wide">{code}</h2>
        </div>
        <div className="flex items-center gap-2">
          <button className="btn btn-outline" onClick={()=>navigator.clipboard.writeText(location.origin + '?room=' + code)}>Copiar link</button>
          <button className="btn btn-outline" onClick={()=>{ leaveRoom(code, me.uid); goHome(); }}>Sair</button>
        </div>
      </header>

      {/* Players */}
      <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-4">
        {(room.players||[]).map((p:any)=>(
          <div key={p.uid} className="card p-3 grid gap-2">
            <div className="flex items-center justify-between">
              <div className="font-semibold">{p.name}</div>
              <div className="pill">{p.vocation}</div>
            </div>
            <div className="flex items-center justify-between text-sm">
              <div className="pill">HP {p.hp}</div>
              <div className="pill">Moedas {p.coins}</div>
            </div>
            <div className="text-xs opacity-70">Status: {p.alive? 'vivo':'eliminado'}</div>
            {room.status==='lobby' && p.uid===me.uid && (
              <button className="btn" onClick={()=>setReady(code, me.uid, !p.ready)}>{p.ready? 'Desmarcar Pronto':'Estou Pronto'}</button>
            )}
          </div>
        ))}
      </div>

      {/* Lobby controls */}
      {room.status==='lobby' && (
        <div className="card p-4 flex items-center justify-between">
          <div className="text-sm opacity-80">Aguardando 4 jogadores marcarem pronto.</div>
          {isOwner(room, me.uid) && <button className="btn" disabled={!canStart} onClick={()=>startGame(code)}>JOGAR</button>}
        </div>
      )}

      {/* Game area */}
      {room.status!=='lobby' && (
        <div className="grid gap-4">
          <div className="card p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="pill">Rodada {room.round}</div>
              <div className="pill">Fase: {room.phase}</div>
              <div className="pill">Tempo: {Math.max(0, Math.floor((room.phaseEndsAt - Date.now())/1000))}s</div>
              <div className="pill">Vivos: {(room.players||[]).filter((p:any)=>p.alive).length}</div>
              <div className="pill">Custos: {allowedCostsForRound(room.round).join(', ')}</div>
            </div>
            {isOwner(room, me.uid) && room.phase==='shop' && (
              <button className="btn btn-outline" onClick={()=>nextPhaseIfNeeded(code, room, true)}>Encerrar fase agora</button>
            )}
          </div>

          <div className="grid gap-4 lg:grid-cols-4">
            <div className="lg:col-span-3 grid gap-3">
              <div className="card p-3 grid gap-2">
                <div className="font-semibold">Seu Campo</div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  <div>
                    <div className="text-xs opacity-60 mb-1">Frente</div>
                    <div className="grid gap-2">
                      {(mePlayer?.board?.front||[]).map((u:any, i:number)=>(
                        <div key={u.id} className="relative">
                          <UnitCard u={u} />
                          <button className="btn btn-outline absolute -right-2 -top-2 px-2 py-1" onClick={()=>removeFromBoard(code, me.uid, 'front', i)}>×</button>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs opacity-60 mb-1">Trás</div>
                    <div className="grid gap-2">
                      {(mePlayer?.board?.back||[]).map((u:any, i:number)=>(
                        <div key={u.id} className="relative">
                          <UnitCard u={u} />
                          <button className="btn btn-outline absolute -right-2 -top-2 px-2 py-1" onClick={()=>removeFromBoard(code, me.uid, 'back', i)}>×</button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="card p-3 grid gap-2">
                <div className="font-semibold">Banco ({mePlayer?.bench?.length||0})</div>
                <div className="grid gap-2">
                  {(mePlayer?.bench||[]).map((u:any, idx:number)=>(
                    <div key={u.id}>
                      <UnitCard u={u} />
                      <div className="mt-1 flex gap-2">
                        <button className="btn btn-outline" onClick={()=>deployFromBench(code, me.uid, idx, 'front')}>Frente</button>
                        <button className="btn btn-outline" onClick={()=>deployFromBench(code, me.uid, idx, 'back')}>Trás</button>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-2">
                  <button className="btn btn-outline" onClick={()=>autoDeploy(code, me.uid)}>Auto-posicionar</button>
                </div>
              </div>
            </div>

            <div className="lg:col-span-1 grid gap-3">
              <div className="card p-3 grid gap-2">
                <div className="font-semibold">Loja</div>
                {(myShop||[]).map((b:any, i:number)=>(
                  <div key={i}>
                    <UnitCard u={b} />
                    <div className="mt-1 flex gap-2">
                      <button className="btn" onClick={()=>buyCard(code, me.uid, b)}>Comprar (C{b.cost})</button>
                    </div>
                  </div>
                ))}
                <button className="btn btn-outline" onClick={()=>reroll(code, me.uid)}>Novas 5 cartas (3 moedas)</button>
              </div>

              <div className="card p-3 grid gap-2">
                <div className="font-semibold">Registro</div>
                <div className="text-sm opacity-90 space-y-1 max-h-[300px] overflow-auto">
                  {(room.logs||[]).slice(-200).map((l:any, i:number)=>(<div key={i}>• {l.text}</div>))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
