
import React, { useEffect, useState } from 'react';
import { createRoom, joinRoom, codeExists } from '../lib/room';
import { getOrCreateClient } from '../lib/client';

export function Lobby({ goRoom }: { goRoom: (code: string)=>void }) {
  const [name, setName] = useState(localStorage.getItem('name') || '');
  const [vocation, setVocation] = useState<'Knight'|'Paladin'|'Sorcerer'|'Druid'>('Knight');
  const [code, setCode] = useState('');

  useEffect(()=>{ localStorage.setItem('name', name); }, [name]);

  async function handleCreate() {
    if (!name.trim()) return alert('Digite um nome');
    const me = getOrCreateClient();
    const code = await createRoom({ ownerUid: me.uid, ownerName: name });
    const okJoin = await joinRoom(code, { uid: me.uid, name, vocation });
    if (!okJoin) return alert('Falha ao entrar na sala.');
    goRoom(code);
  }

  async function handleJoin() {
    if (!name.trim()) return alert('Digite um nome');
    const me = getOrCreateClient();
    const ok = await codeExists(code.toUpperCase());
    if (!ok) return alert('Sala não encontrada');
    const okJoin = await joinRoom(code.toUpperCase(), { uid: me.uid, name, vocation });
    if (!okJoin) return alert('Sala cheia ou já começou.');
    goRoom(code.toUpperCase());
  }

  return (
    <div className="max-w-3xl mx-auto p-6 grid gap-6">
      <header className="grid gap-2">
        <h1 className="text-2xl font-bold">Jogo do Feefis — Multiplayer</h1>
        <p className="opacity-70">Crie uma sala, chame 3 amigos e joguem em tempo real. 30s de loja/posicionamento por rodada.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="card p-4 grid gap-3">
          <div className="grid gap-2">
            <label className="text-sm opacity-80">Seu nome</label>
            <input className="input" placeholder="Seu nome" value={name} onChange={e=>setName(e.target.value)} />
          </div>
          <div className="grid gap-2">
            <label className="text-sm opacity-80">Vocação</label>
            <select className="input" value={vocation} onChange={e=>setVocation(e.target.value as any)}>
              <option>Knight</option>
              <option>Paladin</option>
              <option>Sorcerer</option>
              <option>Druid</option>
            </select>
          </div>
          <button className="btn" onClick={handleCreate}>Criar Sala</button>
        </div>

        <div className="card p-4 grid gap-3">
          <div className="grid gap-2">
            <label className="text-sm opacity-80">Código da sala</label>
            <input className="input" placeholder="ABC123" value={code} onChange={e=>setCode(e.target.value)} />
          </div>
          <div className="grid gap-2">
            <label className="text-sm opacity-80">Seu nome</label>
            <input className="input" placeholder="Seu nome" value={name} onChange={e=>setName(e.target.value)} />
          </div>
          <div className="grid gap-2">
            <label className="text-sm opacity-80">Vocação</label>
            <select className="input" value={vocation} onChange={e=>setVocation(e.target.value as any)}>
              <option>Knight</option>
              <option>Paladin</option>
              <option>Sorcerer</option>
              <option>Druid</option>
            </select>
          </div>
          <button className="btn btn-outline" onClick={handleJoin}>Entrar na Sala</button>
        </div>
      </div>
    </div>
  );
}
