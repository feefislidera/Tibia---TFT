
import React, { useEffect, useState } from 'react';
import { Lobby } from './Lobby';
import { Room } from './Room';
import { getOrCreateClient } from '../lib/client';

export type View = { name: 'lobby' } | { name: 'room', code: string };

export default function App() {
  const [view, setView] = useState<View>(() => {
    const params = new URLSearchParams(location.search);
    const code = params.get('room');
    if (code) return { name: 'room', code };
    return { name: 'lobby' };
  });

  useEffect(() => { getOrCreateClient(); }, []);

  if (view.name === 'lobby') return <Lobby goRoom={(code)=>setView({name:'room', code})} />;
  return <Room code={view.code} goHome={()=>setView({name:'lobby'})} />;
}
