
import { ref, set, get, update, child, remove } from 'firebase/database';
import { db } from '../firebase';
import { UNITS } from '../game/data';
import { allowedCostsForRound, coinsForRound, hasCombat, pairingsForRound, cloneUnit, battle } from '../game/logic';

export const roomsRef = ref(db, 'rooms');

function code6() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let s = '';
  for (let i=0;i<6;i++) s += chars[Math.floor(Math.random()*chars.length)];
  return s;
}

export async function codeExists(code: string) {
  const snap = await get(child(roomsRef, code));
  return snap.exists();
}

export function getRoomRef(code: string) { return child(roomsRef, code); }

export async function createRoom({ ownerUid, ownerName }:{ ownerUid: string, ownerName: string }) {
  let code = code6();
  while (await codeExists(code)) code = code6();
  const room = {
    ownerUid,
    status: 'lobby',
    round: 0,
    phase: 'shop',
    phaseEndsAt: 0,
    logs: [],
    players: [],
    shop: {},
    seats: {}, // seat->uid
    createdAt: Date.now(),
  } as any;
  await set(getRoomRef(code), room);
  return code;
}

export function isOwner(room: any, uid: string) { return room?.ownerUid === uid; }

export async function joinRoom(code: string, { uid, name, vocation }: { uid: string, name: string, vocation: 'Knight'|'Paladin'|'Sorcerer'|'Druid' }) {
  const r = getRoomRef(code);
  const snap = await get(r);
  if (!snap.exists()) return false;
  const room = snap.val();
  if (room.status !== 'lobby') return false;
  const players = room.players || [];
  if (players.find((p:any)=>p.uid===uid)) return true;
  if (players.length >= 4) return false;
  const usedSeats = new Set((players.map((p:any)=>p.seat)));
  let seat = 1; while (usedSeats.has(seat)) seat++;
  const player = {
    uid, name, vocation, seat,
    hp: 100, coins: 0, alive: true, ready: false,
    bench: [], board: { front: [], back: [] },
  };
  players.push(player);
  await update(r, { players });
  return true;
}

export async function leaveRoom(code: string, uid: string) {
  const r = getRoomRef(code);
  const snap = await get(r);
  if (!snap.exists()) return;
  const room = snap.val();
  let players = (room.players||[]).filter((p:any)=>p.uid!==uid);
  let ownerUid = room.ownerUid;
  if (ownerUid === uid && players.length>0) ownerUid = players[0].uid;
  if (players.length===0) {
    await remove(r);
    return;
  }
  await update(r, { players, ownerUid });
}

function rollShop(round: number) {
  const costs = allowedCostsForRound(round);
  const pool = UNITS.filter(u=>costs.includes(u.cost));
  const used = new Set<number>();
  const options: any[] = [];
  while (options.length<5 && used.size < pool.length) {
    const idx = Math.floor(Math.random()*pool.length);
    if (used.has(idx)) continue;
    used.add(idx);
    options.push(pool[idx]);
  }
  return options;
}

function tryMerge(p: any, baseName: string, logs: any[]) {
  const same = (p.bench||[]).filter((u:any)=>u.base.name===baseName && u.level===1);
  if (same.length>=3) {
    let removed = 0;
    p.bench = p.bench.filter((u:any)=>{
      if (removed<3 && u.base.name===baseName && u.level===1) { removed++; return false; }
      return true;
    });
    const base = UNITS.find(u=>u.name===baseName)!;
    p.bench.push({ base, level: 2, id: `unit_${Math.random().toString(36).slice(2,9)}` });
    logs.push({ text: `Evolução: 3x ${baseName} => ${baseName} Nível 2` });
  }
}

export async function setReady(code: string, uid: string, ready: boolean) {
  const r = getRoomRef(code);
  const snap = await get(r);
  if (!snap.exists()) return;
  const room = snap.val();
  const players = (room.players||[]).map((p:any)=> p.uid===uid ? { ...p, ready } : p);
  await update(r, { players });
}

export async function startGame(code: string) {
  const r = getRoomRef(code);
  const snap = await get(r);
  if (!snap.exists()) return;
  const room = snap.val();
  const players = (room.players||[]).map((p:any)=> ({
    ...p, ready:false, hp:100, coins:0, alive:true, bench:[], board:{front:[], back:[]}
  }));
  const round = 1;
  const shop: any = {};
  for (const p of players) {
    const any = UNITS[Math.floor(Math.random()*UNITS.length)];
    p.bench.push({ base:any, level:1, id: `unit_${Math.random().toString(36).slice(2,9)}` });
    shop[p.uid] = rollShop(round);
  }
  const logs = [{ text: 'Partida iniciada. R1: cada jogador recebeu 1 carta.' }];
  const phaseEndsAt = Date.now() + 30_000;
  await update(r, { status:'playing', round, phase:'shop', phaseEndsAt, players, shop, logs });
}

export async function nextPhaseIfNeeded(code: string, roomOrNull?: any, force=false) {
  const r = getRoomRef(code);
  const snap = roomOrNull ? { exists: ()=>true, val: ()=>roomOrNull } : await get(r);
  if (!snap.exists()) return;
  const room = snap.val();
  if (room.status!=='playing') return;
  if (room.phase==='shop' && (Date.now() >= room.phaseEndsAt || force)) {
    // Batalha (se aplicável), depois próxima rodada ou fim
    const logs = room.logs || [];
    let players = room.players || [];
    // auto-deploy se board vazio
    for (const p of players) {
      if ((p.board.front.length + p.board.back.length)===0 && p.bench.length>0) {
        autoDeployLocal(p);
      }
    }
    if (hasCombat(room.round)) {
      const pairs = pairingsForRound(room.round);
      for (const [a,b] of pairs) {
        const A = players.find((p:any)=>p.seat===a);
        const B = players.find((p:any)=>p.seat===b);
        if (!A || !B || !A.alive || !B.alive) { logs.push({ text:`R${room.round}: ${a}x${b} não ocorreu.` }); continue; }
        const res = battle(A.board, B.board);
        const winner = res.winner === 1 ? A : B;
        const loser  = res.winner === 1 ? B : A;
        loser.hp -= res.vidaDano;
        logs.push({ text:`R${room.round}: ${A.name} vs ${B.name} — vencedor ${winner.name} | dano de vida ${res.vidaDano}` });
        if (loser.hp <= 0) { loser.hp = 0; loser.alive = False as any as boolean; logs.push({ text: `${loser.name} foi eliminado!` }); }
      }
    } else {
      logs.push({ text:`R${room.round}: Sem combate.` });
    }
    // limpar boards devolvendo ao banco
    for (const p of players) {
      p.bench = [...(p.board.front||[]), ...(p.board.back||[]), ...(p.bench||[])];
      p.board = { front: [], back: [] };
    }
    // Próxima rodada
    let round = room.round + 1;
    // Condições de fim
    const vivos = players.filter((p:any)=>p.alive);
    if (vivos.length <= 1 || round > 12) {
      const champ = vivos[0];
      if (champ) logs.push({ text: `Campeão: ${champ.name}` });
      await update(r, { players, logs, status: 'finished', phase: 'battle', phaseEndsAt: Date.now() });
      return;
    }
    // distribuir moedas e loja
    const shop:any = {};
    for (const p of players) {
      if (!p.alive) continue;
      if (round >= 2) p.coins += coinsForRound(round);
      shop[p.uid] = rollShop(round);
    }
    const phaseEndsAt = Date.now() + 30_000;
    await update(r, { players, logs, round, shop, phase:'shop', phaseEndsAt });
  }
}

export function autoDeployLocal(p:any) {
  const take = Math.min(8, p.bench.length);
  const picked = p.bench.slice(0, take);
  p.bench = p.bench.slice(take);
  const half = Math.ceil(picked.length/2);
  p.board = { front: picked.slice(0, half), back: picked.slice(half) };
}

export async function autoDeploy(code: string, uid: string) {
  const r = getRoomRef(code);
  const snap = await get(r);
  if (!snap.exists()) return;
  const room = snap.val();
  const players = (room.players||[]).map((p:any)=>{
    if (p.uid!==uid) return p;
    autoDeployLocal(p);
    return p;
  });
  await update(r, { players });
}

export async function buyCard(code: string, uid: string, base: any) {
  const r = getRoomRef(code);
  const snap = await get(r);
  if (!snap.exists()) return;
  const room = snap.val();
  if (room.phase!=='shop') return;
  const round = room.round;
  const allowed = allowedCostsForRound(round);
  const players = room.players||[];
  const logs = room.logs||[];
  const p = players.find((x:any)=>x.uid===uid);
  if (!p || !p.alive) return;
  if (!allowed.includes(base.cost)) return;
  if (p.coins < base.cost) return;
  p.coins -= base.cost;
  p.bench.push({ base, level:1, id: `unit_${Math.random().toString(36).slice(2,9)}` });
  tryMerge(p, base.name, logs);
  await update(r, { players, logs });
}

export async function reroll(code: string, uid: string) {
  const r = getRoomRef(code);
  const snap = await get(r);
  if (!snap.exists()) return;
  const room = snap.val();
  if (room.phase!=='shop') return;
  const players = room.players||[];
  const p = players.find((x:any)=>x.uid===uid);
  if (!p || !p.alive) return;
  if (p.coins < 3) return;
  p.coins -= 3;
  const shop = room.shop||{};
  shop[uid] = rollShop(room.round);
  const logs = room.logs||[];
  logs.push({ text: `${p.name} gastou 3 moedas para novas cartas na loja.` });
  await update(r, { players, shop, logs });
}

export async function deployFromBench(code: string, uid: string, idx: number, lane: 'front'|'back') {
  const r = getRoomRef(code);
  const snap = await get(r);
  if (!snap.exists()) return;
  const room = snap.val();
  if (room.phase!=='shop') return;
  const players = room.players||[];
  const p = players.find((x:any)=>x.uid===uid);
  if (!p || !p.alive) return;
  const total = (p.board.front?.length||0) + (p.board.back?.length||0);
  if (total >= 8) return;
  const u = p.bench[idx];
  if (!u) return;
  p.bench.splice(idx, 1);
  p.board[lane].push(u);
  await update(r, { players });
}

export async function removeFromBoard(code: string, uid: string, lane: 'front'|'back', idx: number) {
  const r = getRoomRef(code);
  const snap = await get(r);
  if (!snap.exists()) return;
  const room = snap.val();
  if (room.phase!=='shop') return;
  const players = room.players||[];
  const p = players.find((x:any)=>x.uid===uid);
  if (!p || !p.alive) return;
  const u = p.board[lane][idx];
  if (!u) return;
  p.board[lane].splice(idx,1);
  p.bench.push(u);
  await update(r, { players });
}
