
export function getOrCreateClient() {
  let uid = localStorage.getItem('uid');
  if (!uid) {
    uid = 'p_' + Math.random().toString(36).slice(2, 10).toUpperCase();
    localStorage.setItem('uid', uid);
  }
  return { uid };
}
