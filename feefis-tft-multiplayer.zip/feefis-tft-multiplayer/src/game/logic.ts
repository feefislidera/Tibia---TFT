
import type { Board, UnitBase, UnitInstance, Tribe } from './data';
import { SYNERGIES } from './data';

export function levelUpStats(u: UnitInstance) {
  const mult = u.level === 2 ? 1.5 : 1.0;
  return {
    atk: Math.round(u.base.atk * mult),
    def: Math.round(u.base.def * mult),
    sup: Math.round(u.base.sup * mult),
  };
}

export function allowedCostsForRound(round: number): number[] {
  if (round <= 3) return [1];
  if (round === 4) return [1,2];
  if (round <= 6) return [1,2,3];
  if (round <= 8) return [1,2,3,4];
  return [1,2,3,4,5];
}

export function coinsForRound(_: number) { return 3; }
export function hasCombat(round: number) { return round >= 4 && round <= 12; }

export function pairingsForRound(round: number): [number, number][] {
  const key = ((round - 4) % 3 + 4);
  if (key === 4) return [[1,3],[2,4]];
  if (key === 5) return [[1,4],[2,3]];
  return [[1,2],[3,4]];
}

export function synergyBonus(units: UnitInstance[]): [number, number, number] {
  const counts: Record<Exclude<Tribe,'Boss'>, number> = { Rook:0, Dragon:0, Lutador:0, Mago:0, Tank:0 };
  for (const u of units) {
    if (u.base.tribe === 'Boss') continue;
    counts[u.base.tribe]++;
  }
  let bonus: [number, number, number] = [0,0,0];
  (Object.keys(counts) as (keyof typeof counts)[]).forEach((tribe)=>{
    const c = counts[tribe];
    const tiers = [8,6,4,2];
    for (const t of tiers){
      if (c >= t) {
        const add = SYNERGIES[tribe][t];
        bonus = [bonus[0]+add[0], bonus[1]+add[1], bonus[2]+add[2]];
        break;
      }
    }
  });
  return bonus;
}

export function cloneUnit(base: UnitBase, level: 1|2 = 1): UnitInstance {
  return { base, level, id: `unit_${Math.random().toString(36).slice(2,9)}` };
}

export type BattleResult = { winner: 1|2; survivors: UnitInstance[]; vidaDano: number; log: {text:string}[] };

export function battle(p1: Board, p2: Board): BattleResult {
  const log: {text: string}[] = [];
  const team1 = [...p1.front, ...p1.back].map(cloneCopy);
  const team2 = [...p2.front, ...p2.back].map(cloneCopy);
  function cloneCopy(u: any) { return { ...u, id: `b_${u.id}` }; }

  const buff1 = computeTeamBuff(team1);
  const buff2 = computeTeamBuff(team2);

  const hp1 = team1.map((u:any) => levelUpStats(u).def + buff1.def).map(d => d * 10);
  const hp2 = team2.map((u:any) => levelUpStats(u).def + buff2.def).map(d => d * 10);

  const f1 = Math.min(p1.front.length, team1.length);
  const f2 = Math.min(p2.front.length, team2.length);

  const atkVal1 = (()=>{
    const supTotal = team1.reduce((s:any,u:any)=>s+levelUpStats(u).sup,0) + team1.length * buff1.sup;
    const perUnitBonus = Math.floor(supTotal / Math.max(1, team1.length));
    return Math.max(1, perUnitBonus);
  })();
  const atkVal2 = (()=>{
    const supTotal = team2.reduce((s:any,u:any)=>s+levelUpStats(u).sup,0) + team2.length * buff2.sup;
    const perUnitBonus = Math.floor(supTotal / Math.max(1, team2.length));
    return Math.max(1, perUnitBonus);
  })();

  function firstAliveFrontIdx(hp: number[], totalLenFront: number): number | null {
    for (let i=0;i<totalLenFront && i<hp.length;i++) if (hp[i] > 0) return i;
    for (let i=0;i<hp.length;i++) if (hp[i] > 0) return i;
    return null;
  }

  function attack(attackerTeam: 1|2) {
    if (attackerTeam === 1) {
      const aIdx = hp1.findIndex(h=>h>0); if (aIdx===-1) return;
      const targetIdx = firstAliveFrontIdx(hp2, f2); if (targetIdx==null) return;
      const atk = levelUpStats(team1[aIdx]).atk + buff1.atk + atkVal1;
      const dmg = Math.max(10, atk*10);
      hp2[targetIdx] -= dmg;
      log.push({ text: `${team1[aIdx].base.name} (P1) causou ${dmg} em ${team2[targetIdx].base.name} (P2)` });
    } else {
      const aIdx = hp2.findIndex(h=>h>0); if (aIdx===-1) return;
      const targetIdx = firstAliveFrontIdx(hp1, f1); if (targetIdx==null) return;
      const atk = levelUpStats(team2[aIdx]).atk + buff2.atk + atkVal2;
      const dmg = Math.max(10, atk*10);
      hp1[targetIdx] -= dmg;
      log.push({ text: `${team2[aIdx].base.name} (P2) causou ${dmg} em ${team1[targetIdx].base.name} (P1)` });
    }
  }

  let turn: 1|2 = 1;
  let guard = 0;
  while (hp1.some(h=>h>0) && hp2.some(h=>h>0) && guard < 500) {
    attack(turn);
    turn = (3 - turn) as 1|2;
    guard++;
  }

  const p1Alive = hp1.some(h=>h>0);
  const winner: 1|2 = p1Alive ? 1 : 2;
  const winnerTeam = winner === 1 ? team1 : team2;
  const winnerHP = winner === 1 ? hp1 : hp2;
  const survivors = winnerTeam.filter((_:any, i:number)=>winnerHP[i] > 0);
  const vidaDano = 1 + survivors.reduce((s:number,u:any)=>s+u.base.vidaPerdida, 0);
  return { winner, survivors, vidaDano, log };
}

export function computeTeamBuff(units: UnitInstance[]): { atk:number; def:number; sup:number } {
  const [sAtk, sDef, sSup] = synergyBonus(units);
  return { atk: sAtk, def: sDef, sup: sSup };
}
