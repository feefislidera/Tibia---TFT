
export type Tribe = 'Rook' | 'Dragon' | 'Lutador' | 'Mago' | 'Tank' | 'Boss';
export type Vocation = 'Knight' | 'Paladin' | 'Sorcerer' | 'Druid';
export type UnitBase = {
  name: string;
  tribe: Tribe;
  cost: 1|2|3|4|5;
  atk: number; def: number; sup: number;
  vidaPerdida: number;
};
export type UnitInstance = { base: UnitBase; level: 1|2; id: string };
export type Board = { front: UnitInstance[]; back: UnitInstance[] };

export const UNITS: UnitBase[] = [
  { name: 'Rat', tribe: 'Rook', cost: 1, atk: 1, def: 1, sup: 1, vidaPerdida: 1 },
  { name: 'Troll', tribe: 'Rook', cost: 1, atk: 2, def: 2, sup: 1, vidaPerdida: 2 },
  { name: 'Fire Devil', tribe: 'Mago', cost: 1, atk: 3, def: 1, sup: 1, vidaPerdida: 2 },
  { name: 'Fire Elemental', tribe: 'Mago', cost: 1, atk: 3, def: 1, sup: 0, vidaPerdida: 2 },
  { name: 'Wolf', tribe: 'Lutador', cost: 1, atk: 2, def: 1, sup: 1, vidaPerdida: 1 },
  { name: 'Bear', tribe: 'Lutador', cost: 1, atk: 3, def: 2, sup: 0, vidaPerdida: 2 },
  { name: 'Rotworm', tribe: 'Tank', cost: 1, atk: 1, def: 3, sup: 1, vidaPerdida: 2 },
  { name: 'Orc', tribe: 'Tank', cost: 1, atk: 2, def: 2, sup: 1, vidaPerdida: 2 },
  { name: 'Elf', tribe: 'Dragon', cost: 1, atk: 2, def: 1, sup: 1, vidaPerdida: 1 },
  { name: 'Dragon Hatchling', tribe: 'Dragon', cost: 1, atk: 3, def: 2, sup: 0, vidaPerdida: 2 },
  { name: 'Minotaur', tribe: 'Rook', cost: 2, atk: 3, def: 3, sup: 2, vidaPerdida: 3 },
  { name: 'Dwarf', tribe: 'Rook', cost: 2, atk: 3, def: 2, sup: 2, vidaPerdida: 3 },
  { name: 'Witch', tribe: 'Mago', cost: 2, atk: 4, def: 1, sup: 1, vidaPerdida: 3 },
  { name: 'Dark Apprentice', tribe: 'Mago', cost: 2, atk: 4, def: 1, sup: 2, vidaPerdida: 3 },
  { name: 'Goblin', tribe: 'Lutador', cost: 2, atk: 3, def: 2, sup: 1, vidaPerdida: 2 },
  { name: 'Barbarian', tribe: 'Lutador', cost: 2, atk: 4, def: 3, sup: 0, vidaPerdida: 3 },
  { name: 'Gargoyle', tribe: 'Tank', cost: 2, atk: 2, def: 4, sup: 2, vidaPerdida: 3 },
  { name: 'Monk', tribe: 'Tank', cost: 2, atk: 2, def: 3, sup: 3, vidaPerdida: 3 },
  { name: 'Wyvern', tribe: 'Dragon', cost: 2, atk: 4, def: 2, sup: 1, vidaPerdida: 3 },
  { name: 'Frost Dragon Hatchling', tribe: 'Dragon', cost: 2, atk: 3, def: 3, sup: 1, vidaPerdida: 3 },
  { name: 'Cyclops', tribe: 'Rook', cost: 3, atk: 5, def: 5, sup: 3, vidaPerdida: 4 },
  { name: 'Amazon', tribe: 'Rook', cost: 3, atk: 4, def: 4, sup: 3, vidaPerdida: 4 },
  { name: 'Valkyrie', tribe: 'Rook', cost: 3, atk: 5, def: 4, sup: 2, vidaPerdida: 4 },
  { name: 'Necromancer', tribe: 'Mago', cost: 3, atk: 7, def: 2, sup: 3, vidaPerdida: 5 },
  { name: 'Priestess', tribe: 'Mago', cost: 3, atk: 6, def: 2, sup: 3, vidaPerdida: 4 },
  { name: 'Bonelord', tribe: 'Mago', cost: 3, atk: 6, def: 3, sup: 2, vidaPerdida: 4 },
  { name: 'Ghoul', tribe: 'Lutador', cost: 3, atk: 5, def: 4, sup: 2, vidaPerdida: 4 },
  { name: 'Skeleton Warrior', tribe: 'Lutador', cost: 3, atk: 6, def: 4, sup: 1, vidaPerdida: 4 },
  { name: 'Hunter', tribe: 'Lutador', cost: 3, atk: 5, def: 3, sup: 3, vidaPerdida: 4 },
  { name: 'Giant Spider', tribe: 'Tank', cost: 3, atk: 4, def: 7, sup: 2, vidaPerdida: 5 },
  { name: 'Stone Golem', tribe: 'Tank', cost: 3, atk: 3, def: 7, sup: 3, vidaPerdida: 5 },
  { name: 'Priest of the Light', tribe: 'Tank', cost: 3, atk: 4, def: 6, sup: 3, vidaPerdida: 5 },
  { name: 'Dragon', tribe: 'Dragon', cost: 3, atk: 7, def: 4, sup: 2, vidaPerdida: 5 },
  { name: 'Frost Dragon', tribe: 'Dragon', cost: 3, atk: 6, def: 5, sup: 2, vidaPerdida: 5 },
  { name: 'Hydra Hatchling', tribe: 'Dragon', cost: 3, atk: 6, def: 4, sup: 3, vidaPerdida: 5 },
  { name: 'Hero', tribe: 'Rook', cost: 4, atk: 8, def: 7, sup: 4, vidaPerdida: 6 },
  { name: 'Lich', tribe: 'Rook', cost: 4, atk: 7, def: 7, sup: 4, vidaPerdida: 6 },
  { name: 'Warlock Servant', tribe: 'Rook', cost: 4, atk: 8, def: 6, sup: 5, vidaPerdida: 6 },
  { name: 'Warlock', tribe: 'Mago', cost: 4, atk: 12, def: 3, sup: 4, vidaPerdida: 7 },
  { name: 'Grim Reaper', tribe: 'Mago', cost: 4, atk: 10, def: 4, sup: 5, vidaPerdida: 7 },
  { name: 'Infernalist', tribe: 'Mago', cost: 4, atk: 11, def: 4, sup: 3, vidaPerdida: 7 },
  { name: 'Behemoth', tribe: 'Lutador', cost: 4, atk: 9, def: 8, sup: 4, vidaPerdida: 7 },
  { name: 'Juggernaut Spawn', tribe: 'Lutador', cost: 4, atk: 10, def: 7, sup: 3, vidaPerdida: 7 },
  { name: 'Undead Gladiator', tribe: 'Lutador', cost: 4, atk: 9, def: 8, sup: 3, vidaPerdida: 6 },
  { name: 'Dark Torturer', tribe: 'Tank', cost: 4, atk: 7, def: 10, sup: 4, vidaPerdida: 7 },
  { name: 'Hellhound', tribe: 'Tank', cost: 4, atk: 6, def: 9, sup: 5, vidaPerdida: 7 },
  { name: 'Massive Fire Elemental', tribe: 'Tank', cost: 4, atk: 7, def: 9, sup: 4, vidaPerdida: 7 },
  { name: 'Dragon Lord', tribe: 'Dragon', cost: 4, atk: 11, def: 7, sup: 4, vidaPerdida: 7 },
  { name: 'Frost Dragon Noble', tribe: 'Dragon', cost: 4, atk: 10, def: 8, sup: 3, vidaPerdida: 7 },
  { name: 'Ghastly Dragon', tribe: 'Dragon', cost: 4, atk: 12, def: 6, sup: 4, vidaPerdida: 7 },
  { name: 'Ferumbras', tribe: 'Boss', cost: 5, atk: 15, def: 9, sup: 7, vidaPerdida: 12 },
  { name: 'Orshabaal', tribe: 'Boss', cost: 5, atk: 14, def: 10, sup: 6, vidaPerdida: 11 },
  { name: 'Ghazbaran', tribe: 'Boss', cost: 5, atk: 12, def: 14, sup: 5, vidaPerdida: 12 },
  { name: 'Morgaroth', tribe: 'Boss', cost: 5, atk: 13, def: 12, sup: 6, vidaPerdida: 11 },
  { name: 'Zushuka', tribe: 'Boss', cost: 5, atk: 12, def: 11, sup: 5, vidaPerdida: 10 },
  { name: 'Bakragore', tribe: 'Boss', cost: 5, atk: 15, def: 10, sup: 6, vidaPerdida: 12 },
];

export const SYNERGIES: Record<Exclude<Tribe,'Boss'>, Record<number,[number,number,number]>> = {
  Rook: { 2:[1,1,1], 4:[3,3,3], 6:[5,5,5], 8:[7,7,7] },
  Dragon: { 2:[4,1,1], 4:[8,2,3], 6:[12,4,5], 8:[14,5,3] },
  Lutador: { 2:[2,1,1], 4:[4,3,3], 6:[6,5,5], 8:[8,7,7] },
  Mago: { 2:[4,0,1], 4:[8,1,2], 6:[13,1,3], 8:[20,1,5] },
  Tank: { 2:[0,4,1], 4:[1,8,2], 6:[1,13,3], 8:[2,18,3] },
};

export const START_HP = 100;
export const MAX_BOARD = 8;

export function uid(prefix='u'){ return `${prefix}_${Math.random().toString(36).slice(2,9)}`; }
